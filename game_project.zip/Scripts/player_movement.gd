extends CharacterBody3D

@export_category("Basic Movement")
@export var SPEED: float = 5.0
@export var SPRINT_SPEED: float = 8.0
const JUMP_VELOCITY: float = 4.5

@export_category("AAA Physics (High Intelligence)")
@export var ACCELERATION: float = 8.0      # কত দ্রুত টপ স্পিডে পৌঁছাবে
@export var DECELERATION: float = 10.0     # ব্রেক কষার ক্ষমতা
@export var AIR_CONTROL: float = 0.3       # বাতাসে থাকা অবস্থায় বডি কন্ট্রোল (৩০%)
@export var ROTATION_SPEED: float = 12.0   # মডেল ঘোরার স্পিড
@export var LEAN_AMOUNT: float = 0.15      # টার্ন নেওয়ার সময় কতটুকু হেলে পড়বে
@export var LEAN_SPEED: float = 8.0        # হেলে পড়া থেকে সোজা হওয়ার স্পিড

# নোড রেফারেন্স (আপনার সিনের হুবহু পাথ)
@onready var head: Node3D = $head
@onready var player_mesh: Node3D = $CollisionShape3D/"Standing Idle"
@onready var anim_player: AnimationPlayer = $CollisionShape3D/"Standing Idle"/AnimationPlayer

# কোয়োটি টাইম (Coyote Time) ট্র্যাকিং ভেরিয়েবল
var coyote_time: float = 0.0
const COYOTE_TIME_MAX: float = 0.15 

func _ready() -> void:
	# AAA ডাইনামিক অ্যানিমেশন স্ক্যানার (FBX পাথ এরর ফিক্সার)
	if anim_player == null and is_instance_valid(player_mesh):
		for child in player_mesh.get_children():
			if child is AnimationPlayer:
				anim_player = child
				print("Success: AnimationPlayer found dynamically inside FBX!")
				break

func _physics_process(delta: float) -> void:
	# ১. ইন্টেলিজেন্ট গ্র্যাভিটি এবং কোয়োটি টাইম
	if is_on_floor():
		coyote_time = COYOTE_TIME_MAX
	else:
		coyote_time -= delta
		velocity.y -= ProjectSettings.get_setting("physics/3d/default_gravity") * delta

	# ২. স্মার্ট জাম্প মেকানিজম
	if Input.is_action_just_pressed("jump") and coyote_time > 0.0:
		velocity.y = JUMP_VELOCITY
		coyote_time = 0.0

	# ৩. ডাইনামিক স্প্রিন্ট
	var current_speed = SPRINT_SPEED if (Input.is_action_pressed("sprint") and is_on_floor()) else SPEED

	# ৪. জয়স্টিক ইনপুট ও ক্যামেরা রিলেটিভ ডিরেকশন
	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var direction := (head.global_transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	direction.y = 0
	direction = direction.normalized()

	# ৫. মোমেন্টাম এবং ফ্রিকশন ক্যালকুলেশন
	var current_accel = ACCELERATION if is_on_floor() else ACCELERATION * AIR_CONTROL
	var current_decel = DECELERATION if is_on_floor() else DECELERATION * 0.2

	# ৬. মুভমেন্ট এবং প্রসিডিউরাল রোটেশন লজিক
	if direction != Vector3.ZERO:
		velocity.x = lerp(velocity.x, direction.x * current_speed, current_accel * delta)
		velocity.z = lerp(velocity.z, direction.z * current_speed, current_accel * delta)

		# ক্যারেক্টার মডেল ঘোরানো (রোটেশন ফিক্সড)
		if is_instance_valid(player_mesh):
			var target_angle = atan2(direction.x, direction.z)
			var angle_diff = wrapf(target_angle - player_mesh.rotation.y, -PI, PI)
			
			player_mesh.rotation.y += angle_diff * ROTATION_SPEED * delta
			
			var speed_ratio = velocity.length() / SPRINT_SPEED
			var target_lean = clamp(-angle_diff * LEAN_AMOUNT * speed_ratio, -LEAN_AMOUNT, LEAN_AMOUNT)
			player_mesh.rotation.z = lerp(player_mesh.rotation.z, target_lean, LEAN_SPEED * delta)
	else:
		# জয়স্টিক ছেড়ে দিলে স্লাইড করে থামা
		velocity.x = lerp(velocity.x, 0.0, current_decel * delta)
		velocity.z = lerp(velocity.z, 0.0, current_decel * delta)

		if is_instance_valid(player_mesh):
			player_mesh.rotation.z = lerp(player_mesh.rotation.z, 0.0, LEAN_SPEED * delta)

	# 🏃‍♂️ ৭. হাই-ইন্টেলিজেন্স অ্যানিমেশন কন্ট্রোল সিস্টেম (মাটিতে থাকা অবস্থায়)
	if is_on_floor():
		if velocity.length() < 0.2:
			# জয়স্টিক নিউট্রাল থাকলে Standing Idle অ্যানিমেশন চলবে
			if is_instance_valid(anim_player):
				if anim_player.current_animation != "standing idle":
					anim_player.play("standing idle", 0.3)
		else:
			# 🔥 জয়স্টিক মুভ করলে Walk বা Run অ্যানিমেশন চলবে
			if is_instance_valid(anim_player):
				# যদি প্লেয়ার স্প্রিন্ট বাটন (Shift) চেপে দৌড়ায়, তবে Run অ্যানিমেশন প্লে হবে
				if Input.is_action_pressed("sprint"):
					if anim_player.current_animation != "mixamo_com": # (ভবিষ্যতের জন্য রান অ্যানিমেশনের নাম)
						anim_player.play("mixamo_com", 0.3)
				else:
					# সাধারণ মুভমেন্টে Walk অ্যানিমেশন চলবে
					if anim_player.current_animation != "walk": 
						anim_player.play("walk", 0.3)

	move_and_slide()
