extends Node3D

@export_category("Camera Settings")
@export var SENSITIVITY: float = 0.003
@export var TOUCH_SPEED_MULTIPLIER: float = 400.0 
@export var CAMERA_SMOOTHNESS: float = 15.0 # ক্যামেরা ঘোরার স্মুথনেস

var target_rotation_x: float = 0.0
var target_rotation_y: float = 0.0

func _ready() -> void:
	# ডেস্কটপ প্ল্যাটফর্মের জন্য মাউস কার্সার হাইড করা
	if OS.get_name() in ["Windows", "macOS", "Linux"]:
		Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	
	target_rotation_y = get_parent().rotation.y
	target_rotation_x = rotation.x

func _process(delta: float) -> void:
	# মোবাইল জয়স্টিক ইনপুট প্রসেস
	_handle_ui_joystick_look(delta)
	
	# লার্পিং এর মাধ্যমে ক্যামেরাকে ওয়ান-ক্লিক ঝটকা মুক্ত করে মোলায়েম ও সিনেমাটিক ফিল দেওয়া
	get_parent().rotation.y = lerp_angle(get_parent().rotation.y, target_rotation_y, CAMERA_SMOOTHNESS * delta)
	rotation.x = lerp_angle(rotation.x, target_rotation_x, CAMERA_SMOOTHNESS * delta)

func _input(event: InputEvent) -> void:
	# পিসিতে মাউস মুভমেন্ট রিড করা
	if event is InputEventMouseMotion and Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
		target_rotation_y -= event.relative.x * SENSITIVITY
		target_rotation_x -= event.relative.y * SENSITIVITY
		# ৩য় পারসন ক্যামেরার রোটেশন লক (মাটির নিচে এবং প্লেয়ারের ঠিক মাথার উপরে লক)
		target_rotation_x = clamp(target_rotation_x, deg_to_rad(-40), deg_to_rad(70))

func _handle_ui_joystick_look(delta: float) -> void:
	var look_vec = Vector2.ZERO
	look_vec.x = Input.get_action_strength("look_right") - Input.get_action_strength("look_left")
	look_vec.y = Input.get_action_strength("look_down") - Input.get_action_strength("look_up")
	
	if look_vec.length() > 0.0:
		target_rotation_y -= look_vec.x * SENSITIVITY * TOUCH_SPEED_MULTIPLIER * delta
		target_rotation_x -= look_vec.y * SENSITIVITY * TOUCH_SPEED_MULTIPLIER * delta
		target_rotation_x = clamp(target_rotation_x, deg_to_rad(-40), deg_to_rad(70))
