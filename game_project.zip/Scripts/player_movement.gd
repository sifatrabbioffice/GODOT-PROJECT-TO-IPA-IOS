extends CharacterBody3D

@export var SPEED: float = 5.0
@export var SPRINT_SPEED: float = 8.0
@export var ACCELERATION: float = 10.0
@export var DECELERATION: float = 8.0
const JUMP_VELOCITY = 4.5

@onready var head: Node3D = $head

func _physics_process(delta: float) -> void:
	# ১. গ্র্যাভিটি বা অভিকর্ষজ বল হিসেব করা
	if not is_on_floor():
		var gravity = ProjectSettings.get_setting("physics/3d/default_gravity")
		velocity.y -= gravity * delta

	# ২. লাফানোর (Jump) মেকানিজম
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# ৩. স্প্রিন্ট বা দৌড়ানোর স্পিড নির্ধারণ
	var current_speed = SPRINT_SPEED if Input.is_action_pressed("sprint") else SPEED

	# ৪. জয়স্টিক বা কিবোর্ডের ভেক্টর ইনপুট নেওয়া
	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	
	# ৫. ক্যামেরার রোটেশনের সাথে ডিরেকশন মেলানো (AAA ক্যামেরা রিলেটিভ মুভমেন্ট)
	var direction := (head.global_transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	direction.y = 0 # প্লেয়ার যেন শূন্যে উড়ে না যায়
	direction = direction.normalized()

	# ৬. লিনিয়ার ইন্টারপোলেশন (Lerp) এর মাধ্যমে স্মুথ মুভমেন্ট তৈরি
	if direction != Vector3.ZERO:
		velocity.x = move_toward(velocity.x, direction.x * current_speed, ACCELERATION * delta)
		velocity.z = move_toward(velocity.z, direction.z * current_speed, ACCELERATION * delta)
	else:
		# ঘর্ষণ বা জড়তার প্রভাব তৈরি করা যেন সাথে সাথে ব্রেক না হয়ে একটু স্লাইড করে থামে
		velocity.x = move_toward(velocity.x, 0, DECELERATION * delta)
		velocity.z = move_toward(velocity.z, 0, DECELERATION * delta)

	move_and_slide()
